package utils;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import static io.restassured.RestAssured.given;

import java.util.Base64;

public class TokenManager {

    // ✅ Replace these with your actual Spotify app details
    private static final String clientId = "25d4f3d693a84421b0283456960a519d";
    private static final String clientSecret = "229c33937632408792d8c48f06cbd4f9";
    private static final String redirectUri = "https://rapaka-balu.github.io/spotify-auth-callback/";

    // ⚠️ This authorization code must be freshly generated (valid for 10 minutes)
    private static final String authorizationCode = "AQBkug6EDHTV7MwxC_eimdqkpjQpIgrymn0bizR54VrO-XL_nD77OfuJsgwkM447mPcijeudOhlR-V8nxk38vceEF5sT6EuZB3f_CCxu56XMSA7i55tUUQJnsA3ZEskEPwRBQp-zvshopzbuXdXXjtjYz8vtM9rfRJUDYGMdnZqLdNfPxlW7LlL4xnIJatGOtExEdy4NL09QYIM06x3hO5XSvN4IdT2_zSps9LyekLwtV-qMJMoitCX-pXeLpFFyvAxmL8Pmnho";
    public static String getAccessToken() {
        RestAssured.baseURI = "https://accounts.spotify.com";

        String credentials = clientId + ":" + clientSecret;
        String encodedCredentials = Base64.getEncoder().encodeToString(credentials.getBytes());

        Response response = given()
            .header("Authorization", "Basic " + encodedCredentials)
            .contentType("application/x-www-form-urlencoded")
            .formParam("grant_type", "authorization_code")
            .formParam("code", authorizationCode)
            .formParam("redirect_uri", redirectUri)
        .when()
            .post("/api/token");

        if (response.statusCode() == 200) {
            String accessToken = response.jsonPath().getString("access_token");
            System.out.println("Access Token: " + accessToken);
            return accessToken;
        } else {
            System.out.println("Failed to get access token");
            System.out.println("Status Code: " + response.statusCode());
            System.out.println("Response: " + response.prettyPrint());
            return null;
        }
    }
}

