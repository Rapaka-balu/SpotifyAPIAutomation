package Tests;

import io.restassured.response.Response;
import org.testng.annotations.Test;
import utils.TokenManager;

import static io.restassured.RestAssured.given;

public class UpdatePlaylistDetailsTest {

    @Test
    public void updatePlaylistDetails() {
        String token = TokenManager.getAccessToken();
        String playlistId = "3EbcQj9qEvZx4xRmVm6Nuw"; // ✅ Use your playlist ID

        String updatedName = "🔥 Balu's Updated Automation Playlist";
        String updatedDescription = "This playlist was updated via REST Assured test!";
        boolean isPublic = false; // Change to true if needed

        Response response = given()
                .baseUri("https://api.spotify.com")
                .header("Authorization", "Bearer " + token)
                .header("Content-Type", "application/json")
                .body("{\n" +
                        "  \"name\": \"" + updatedName + "\",\n" +
                        "  \"description\": \"" + updatedDescription + "\",\n" +
                        "  \"public\": " + isPublic + "\n" +
                        "}")
        .when()
                .put("/v1/playlists/" + playlistId)
        .then()
                .log().all()
                .statusCode(200)
                .extract().response();

        System.out.println("✅ Playlist updated successfully.");
    }
}

