package Tests;



import io.restassured.RestAssured;
import org.testng.annotations.Test;
import utils.TokenManager;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.notNullValue;

public class UserProfileTest {

    @Test
    public void testGetCurrentUserProfile() {
        String token = TokenManager.getAccessToken();

        RestAssured
            .given()
                .baseUri("https://api.spotify.com")
                .basePath("/v1/me")
                .header("Authorization", "Bearer " + token)
            .when()
                .get()
            .then()
                .statusCode(200)
                .body("display_name", notNullValue())
                .body("id", notNullValue());

        System.out.println("✅ User profile test passed!");
    }
}

