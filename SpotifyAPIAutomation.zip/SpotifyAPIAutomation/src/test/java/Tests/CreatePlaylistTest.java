package Tests;


import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import org.testng.annotations.Test;
import utils.TokenManager;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

public class CreatePlaylistTest {

    @Test
    public void createPrivatePlaylist() {
        String token = TokenManager.getAccessToken();

        // Step 1: Get User ID from /me
        RestAssured.baseURI = "https://api.spotify.com";
        String userId = given()
                .header("Authorization", "Bearer " + token)
                .get("/v1/me")
                .then()
                .statusCode(200)
                .extract()
                .path("id");

        // Step 2: Create Playlist
        String playlistName = "🔥 Balu's Automation Playlist";
        String payload = "{\n" +
                "  \"name\": \"" + playlistName + "\",\n" +
                "  \"description\": \"Created via REST Assured automation\",\n" +
                "  \"public\": false\n" +
                "}";

        given()
                .header("Authorization", "Bearer " + token)
                .header("Content-Type", "application/json")
                .body(payload)
        .when()
                .post("/v1/users/" + userId + "/playlists")
        .then()
                .statusCode(201)
                .body("name", equalTo(playlistName));

        System.out.println("✅ Playlist created successfully for user: " + userId);
    }
}
