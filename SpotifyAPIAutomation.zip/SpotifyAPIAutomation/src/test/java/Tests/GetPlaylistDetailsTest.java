package Tests;

import io.restassured.response.Response;
import org.testng.annotations.Test;
import utils.TokenManager;

import static io.restassured.RestAssured.*;

public class GetPlaylistDetailsTest {

    @Test
    public void getPlaylistDetails() {
        String token = TokenManager.getAccessToken();
        String playlistId = "3EbcQj9qEvZx4xRmVm6Nuw"; // 🔁 Replace with your actual playlist ID

        Response response = given()
                .baseUri("https://api.spotify.com")
                .header("Authorization", "Bearer " + token)
                .when()
                .get("/v1/playlists/" + playlistId);

        // 🔍 Debug full response
        response.then().log().all();

        // ✅ Basic assertions
        response.then()
                .statusCode(200)
                .assertThat()
                .body("name", org.hamcrest.Matchers.notNullValue())
                .body("owner.display_name", org.hamcrest.Matchers.notNullValue())
                .body("public", org.hamcrest.Matchers.anyOf(org.hamcrest.Matchers.is(true), org.hamcrest.Matchers.is(false)));
    }
}

