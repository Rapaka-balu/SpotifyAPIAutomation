package Tests;

import org.testng.annotations.Test;

import utils.TokenManager;

public class TokenTest {
@Test
	public void fetchAccessToken() {
		String token = TokenManager.getAccessToken();
		
		System.out.println("Access Token" + token);
		
	}
}

