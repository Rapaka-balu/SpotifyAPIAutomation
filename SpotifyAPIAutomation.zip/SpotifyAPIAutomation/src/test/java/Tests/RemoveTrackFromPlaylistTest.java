package Tests;

import io.restassured.response.Response;
import org.testng.annotations.Test;
import utils.TokenManager;

import static io.restassured.RestAssured.*;

public class RemoveTrackFromPlaylistTest {

    @Test
    public void removeTrackFromPlaylist() {
        String token = TokenManager.getAccessToken();
        String playlistId = "19mfV82AzV5vjk77EpGBN6";
        String trackUri = "spotify:track:19mfV82AzV5vjk77EpGBN6";

        String body = "{ \"tracks\": [ { \"uri\": \"" + trackUri + "\" } ] }";

        Response response = given()
            .baseUri("https://api.spotify.com")
            .header("Authorization", "Bearer " + token)
            .header("Content-Type", "application/json")
            .body(body)
        .when()
            .delete("/v1/playlists/" + playlistId + "/tracks");

        response.then().log().all();
        response.then().statusCode(200);

        System.out.println("✅ Track removed successfully from playlist: " + playlistId);
    }
}

